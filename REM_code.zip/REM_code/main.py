# -*- coding: utf-8 -*-
# -*- coding: utf-8 -*-
"""
Spyder Editor

This Python 3.X script is the main program that calculates the phase stability spinodal decomposition for High Entropy Alloys(HEAs) and other alloys.

This program needs 4 parts, all of them can be edited by TXT reader:
    1. This main.py
    2. MIXING_ENTHALPY: the mixing enthalpy data
    3. INPUT_PARAMETERS: the temperature for the calculation
    4. alloys: the composition of the alloy
    
Good luck!

Hengwei Luan
luanhengwei6770@163.com

To use the script:
    Put all the 4 parts in one folder, edit temperature in INPUT_PARAMETERS.hea4s and alloy in alloys.hea4s, and run the main.py with Python 3.X.
    The result would be in the same folder as the main.py.
"""

"""
units:
    energy:       J
    temperature:  K
    atom_amount:  mol
    atom_fraction:bwtween 0 and 1, without %
"""

import numpy as np
from numpy import linalg as LA
from numpy import float32

import math
import re
import sys 
import datetime
import copy

#gloal constants
#gas contant
R = 8.314 

#periodic_table, periodic_table[1] = H, periodic_table[2] = He, etc
#periodic_table includes No.1 to No.119 elements
periodic_table = ['ELEMENT_NUMBER_START_FROM_ONE','H', 'He', 'Li', 'Be', 'B', 'C', 'N', 'O', 'F', 'Ne', 'Na', 'Mg', 'Al', 'Si', 'P', 'S', 'Cl', 'Ar', 'K', 'Ca', 'Sc', 'Ti', 'V', 'Cr', 'Mn', 'Fe', 'Co', 'Ni', 'Cu', 'Zn', 'Ga', 'Ge', 'As', 'Se', 'Br', 'Kr', 'Rb', 'Sr', 'Y', 'Zr', 'Nb', 'Mo', 'Tc', 'Ru', 'Rh', 'Pd', 'Ag', 'Cd', 'In', 'Sn', 'Sb', 'Te', 'I', 'Xe', 'Cs', 'Ba', 'La', 'Ce', 'Pr', 'Nd', 'Pm', 'Sm', 'Eu', 'Gd', 'Tb', 'Dy', 'Ho', 'Er', 'Tm', 'Yb', 'Lu', 'Hf', 'Ta', 'W', 'Re', 'Os', 'Ir', 'Pt', 'Au', 'Hg', 'Tl', 'Pb', 'Bi', 'Po', 'At', 'Rn', 'Fr', 'Ra', 'Ac', 'Th', 'Pa', 'U', 'Np', 'Pu', 'Am', 'Cm', 'Bk', 'Cf', 'Es', 'Fm','Md', 'No', 'Lr', 'Rf', 'Db', 'Sg', 'Bh', 'Hs', 'Mt', 'Ds', 'Rg', 'Cn', 'Nh', 'Fl', 'Mc', 'Lv', 'Ts', 'Og', 'Uue']

# metallic atomic radius From wikipedia-- Greenwood N N , Earnshaw A (Eds)  - Chemistry Of The Elements-Elsevier (1997)
atomic_size_map = {'Li':152,'Be':112,'Na':186,'Mg':160,'Al':143,'K':227,'Ca':197,'Sc':162,'Ti':147,'V':134,'Cr':128,'Mn':127,'Fe':126,'Co':125,'Ni':124,'Cu':128,'Zn':134,'Ga':135,'Rb':248,'Sr':215,'Y':180,'Zr':160,'Nb':146,'Mo':139,'Tc':136,'Ru':134,'Rh':134,'Pd':137,'Ag':144,'Cd':151,'In':167,'Cs':265,'Ba':222,'La':187,'Ce':181.8,'Pr':182.4,'Nd':181.4,'Pm':183.4,'Sm':180.4,'Eu':180.4,'Gd':180.4,'Tb':177.3,'Dy':178.1,'Ho':176.2,'Er':176.1,'Tm':175.9,'Yb':176,'Lu':173.8,'Hf':159,'Ta':146,'W':139,'Re':137,'Os':135,'Ir':135.5,'Pt':138.5,'Au':144,'Hg':151,'Tl':170,'Th':179,'Pa':163,'U':156,'Np':155,'Pu':159,'Am':173,'Cm':174,'Bk':170,'Cf':186,'Es':186}

#For these with no metallic radiu, we use empirical value
atomic_size_map_empirical = {'Sn':145, 'C':70, 'Si':110,'B':85, 'P':100}

atomic_size_map.update(atomic_size_map_empirical)

#uppered periodic_table, periodic_table[1] = H, periodic_table[2] = HE, etc
#the length and order of uppered periodic_table are the same as periodic_table
periodic_table_uppered = [element.upper() for element in periodic_table]

#uppered atomic_size_map
def lower_to_capital(dict_info):
    new_dict = {}
    for i, j in dict_info.items():
        new_dict[i.upper()] = j
    return new_dict

atomic_size_map_uppered = lower_to_capital(atomic_size_map)

def new_null_list(size):
	newlist = []
	for i in range(0, size):
		newlist.append([])
	return newlist
 
def Isfloat(input_string):
    try:
        float(input_string)
        return True
    except:
        return False
    
def dic_normalization(input_dic):
    sum_value = 0
    for key_item in input_dic:
        sum_value = sum_value + input_dic[key_item]
    for key_item in input_dic:
        input_dic[key_item] = input_dic[key_item]/sum_value
    return input_dic
 
def list_normalize(input_list):
    sum_list_value = math.sqrt(sum(x*x for x in input_list))
    
    for i in range(len(input_list)):
        input_list[i] = input_list[i]/sum_list_value
        
    return input_list
   

class alloy:
    '''
    Base object to define an alloy and provides methods to calculate phase stability.
    Initialization requires composition
    further calculatioin requires mixing enthalpy or/and formation enthalpy of second phases
    '''
    
    def __init__(self,alloy_composition):
        '''
        initialization of alloy
        Parameter:
            input_dic:alloy_composition, with string keys as elements and float values as atomic percentage.
                The sum of the values should be 1
            
        Examples:
            new_alloy = alloy({'AL':0.94,'CU':0.04,'MG':0.02})
            new_alloy = alloy({'FE':0.2,'MN':0.2,'CR':0.2,'CO':0.2,'NI':0.2})
        '''
        self.composition = alloy_composition
        self.elements = list(self.composition.keys())
        
    def clear(self):
        '''
        clear the data in the alloy to save place
        '''
        self.derivative_enthalpy_to_mole = 0
        self.eigenvectors = 0
        self.Hessian_matrix  = 0
        self.derivative_enthalpy_to_mole = 0
        self.derivative_entropy_to_mole = 0
        
        
    def get_mixing_enthalpy(self,enthalpy_map):
        '''
        calculates mixing enthalpy of the alloy
        mixing enthalpy = sum_i(sum_j( 2* mixing_enthalpy_i_j * atomic_fraction_i * atomic_fraction_j))
        The unit of the mixing enthalpy is J/mol for the solid solution
        After using this method, the value of mixing enthalpy by using new_alloy.mixing_enthalpy  
        
        Parameter:
            enthalpy_map: enthalpy map, two dimensional map of the mixng enthalpy
        
        Returns:
            self.mixing_enthalpy: value of mixing enthalpy
            
        '''
        self.mixing_enthalpy = 0
        for element_i in self.composition:
            for element_j in self.composition:
                self.mixing_enthalpy = self.mixing_enthalpy + 2 * enthalpy_map[periodic_table_uppered.index(element_i)][periodic_table_uppered.index(element_j)] * self.composition[element_i] * self.composition[element_j]
        #print(self.mixing_enthalpy)
        return self.mixing_enthalpy
    
    def get_mixing_entropy(self):
        '''
        calculates mixing entropy of the alloy
        mixing entropy = sum_i(-R*atomic_fraction_i*ln(atomic_fraction_i))
        After using this method, the value of mixing entropy by using new_alloy.mixing_entropy 
        
        Returns:
            self.mixing_entropy: value of mixing entropy
        '''
        self.mixing_entropy = 0
        for element_i in self.composition:
            if self.composition[element_i] > 0:
                self.mixing_entropy = self.mixing_entropy - R * self.composition[element_i] * math.log(self.composition[element_i])
        return self.mixing_entropy
        
    

    def print_head(self,enthalpy_map):
        self.get_mixing_enthalpy(enthalpy_map)
        self.get_mixing_entropy()     
        
        composition_short = ''
        for item in self.composition:
            composition_short = composition_short + periodic_table[periodic_table_uppered.index(item)]
        
        SM_data = composition_short + ' # ' + str(self.mixing_enthalpy) + ' # ' + str(self.mixing_entropy)
        return SM_data
    
    
        
        
    def SPINODAL(self,enthalpy_map,Temperature):
        
        element_amount = len(self.composition)
        #self.Hessian_matrix = np.array([[0]*(element_amount-1)]*(element_amount-1))
        
   
        #The condition for spinodal decomposition is obtained from the ''Spinodal Decomposition for Multicomponent'' by Cahn Hilliard Systems Stanislaus Maier-Paape,1 Barbara Stoth,2 and Thomas Wanner3 Received May 20, 1999; final September 21, 1999 
        #please see page 872-874 and an example at page 891
        
        #step 1 calculate D2(W(u))/Du2 (no need to get f)
        D2Wu_Du2 = np.array([[0]*(element_amount)]*(element_amount) , dtype=float32)
        
        for i in range(0,element_amount):
            for j in range(0,element_amount):
                if i == j:
                    D2Wu_Du2[i][j] = R*Temperature*(1/self.composition[self.elements[i]]) #- Temperature*0.5*(D2Se_Dc2(self.composition,self.elements[i],self.elements[i],E_74) + D2Se_Dc2(self.composition,self.elements[i],self.elements[i],E_68))
                else:
                    D2Wu_Du2[i][j] = 4*enthalpy_map[periodic_table_uppered.index(self.elements[i])][periodic_table_uppered.index(self.elements[j])] #- Temperature*0.5*(D2Se_Dc2(self.composition,self.elements[i],self.elements[j],E_74) + D2Se_Dc2(self.composition,self.elements[i],self.elements[j],E_68))
        
        #step 2 calculate P
        P = np.array([[1]*(element_amount)]*(element_amount), dtype=float32)
        for i in range(0,element_amount):
            for j in range(0,element_amount):
                if i == j:
                    P[i][j] = 1 - (1/element_amount)
                else:
                    P[i][j] = - 1/element_amount
                #print(P)
        #step 3 calculate B = -PD2W(u)
        B = - np.dot(P,D2Wu_Du2)
        print(str(B))
        #step 4 get spinodal information
        raw_eigenvalues,raw_eigenvectors= LA.eig(B)
        self.eigenvalues = []
        self.eigenvectors = []
        
        projection_to_e_vertical = abs(np.dot(np.array([1]*element_amount),raw_eigenvectors))
        
        not_our_man_number = np.argmax(projection_to_e_vertical)
        
        for i in range(0,element_amount):
            if not i == not_our_man_number:
                #this wigen vector is vertical to [111], a good one
                self.eigenvalues.append(raw_eigenvalues[i].real)
                self.eigenvectors.append(list(raw_eigenvectors[:,i].real))
        print(str(self.eigenvalues))
        print(str(self.eigenvectors))
        if not len(self.eigenvalues):
            self.eigenvalues.append(0)
            self.eigenvectors.append([1])
            
        if max(self.eigenvalues) > 0:
            self.Is_chem_spinodal_decomposition = True
        else:
            self.Is_chem_spinodal_decomposition = False
              
        ordered_eigenvalues = copy.copy(self.eigenvalues)
        ordered_eigenvalues.sort()
        
        self.max_eigen = ordered_eigenvalues[-1]

        self.max_direction = self.eigenvectors[self.eigenvalues.index(self.max_eigen)]
        
        if element_amount > 2:
            self.max_2_eigen = ordered_eigenvalues[-2]
            self.max_2_direction = self.eigenvectors[self.eigenvalues.index(self.max_2_eigen)]
        else:
            self.max_2_eigen = ordered_eigenvalues[-1]
            self.max_2_direction = self.eigenvectors[self.eigenvalues.index(self.max_2_eigen)]
            
       
        
        
    def print_SPINODAL(self):
        '''
        returns the result of spinodal decomposition calculation
        '''
        
        spinodal_result_summary = ''

        spinodal_result_summary = spinodal_result_summary + ' # ' + str(self.Is_chem_spinodal_decomposition)       
        spinodal_result_summary = spinodal_result_summary + ' # ' + str(-self.max_eigen)
        spinodal_result_summary = spinodal_result_summary + ' # ' + str(self.max_direction)
        spinodal_result_summary = spinodal_result_summary + ' # ' + str(-self.max_2_eigen)
        spinodal_result_summary = spinodal_result_summary + ' # ' + str(self.max_2_direction)        

 
        return spinodal_result_summary
    

        
class input_demand:
    '''
    Base object to define calculation condition
    '''
    def __init__(self):

        self.Do_SPINODAL = False
        self.Temperature = 300

    def __str__(self):
        return ('\nDo_SPINODAL = '+str(self.Do_SPINODAL)+'\nTemperature = '+str(self.Temperature)+'K\n')
    

def mixing_enthalpy_reader(pwd_mixing_enthalpy):
    '''
    input_reader will read mixing enthalpy file: MIXING_ENTHALPY.hea4s
    This function will open the file and search every line to update the coresponding mixing enthalpy
    The mixing enthalpy matrix would be symmetric and the unspecified mixing enthalpy would all be 0.
    the input should look like this:
        Mg Al -2.0
        
    Parameters:
        pwd_mixing_enthalpy: path of the MIXING_ENTHALPY.hea4s. example:'MIXING_ENTHALPY.hea4s'  , 'F:\\HEA_folder\\MIXING_ENTHALPY.hea4s'
    
    returns:
        enthalpy_map: two dimensional list, enthalpy_map[i][j] is the mixing enthalpy of i and j element. e.g.:enthalpy_map[3][5] is the mxing enthalpy of Li and B
        
    Warning: The MIXING_ENTHALPY.hea4s is in the unit of kJ/mol and the returned enthalpy_map would be J/mol
    '''
    try:
        input_file_content = open(pwd_mixing_enthalpy)
        print('MIXING_ENTHALPY.hea4s file found!')
    except:
        print('Can not read MIXING_ENTHALPY.hea4s! Please check the MIXING_ENTHALPY.hea4s file!\n')
        dum = input('Press Enter to exit.')
    else:
        enthalpy_map = np.array([[0]*len(periodic_table)]*len(periodic_table), dtype=float32)
        line_input_counter = 0
        
        for line in input_file_content.readlines():
            if line_input_counter > 2: #skip first 3 lines
                line_content = line.split()
                
                if len(line_content) == 6 and Isfloat(line_content[2]):
                    element_i = line_content[0].upper()
                    element_j = line_content[1].upper()
                    delta_H_i_j = float(line_content[2])
                    
                    if (element_i in periodic_table_uppered) and (element_j in periodic_table_uppered):
                        enthalpy_map[periodic_table_uppered.index(element_i)][periodic_table_uppered.index(element_j)] = delta_H_i_j * 1000#1000 to tranform kJ/mol to J/mol
                        enthalpy_map[periodic_table_uppered.index(element_j)][periodic_table_uppered.index(element_i)] = delta_H_i_j * 1000
                        #print(element_i + str(enthalpy_map[periodic_table_uppered.index(element_i)][periodic_table_uppered.index(element_j)]))
                    else:
                        print('Cannot find element:' + element_i +' or:'+element_j +' in line'+str(line_input_counter+1)+': '+line+' in MIXING_ENTHALPY.hea4s! Please check!')
                        print('The program will skip line'+str(line_input_counter+1)+' and continue.')
                else:
                    print('Cannot read line'+str(line_input_counter+1)+': '+line+' in MIXING_ENTHALPY.hea4s! Please check!')
                    print('The program will skip line'+str(line_input_counter+1)+' and continue.')
            line_input_counter = line_input_counter + 1
        
        print('Successfully read MIXING_ENTHALPY.hea4s!\n')
        return enthalpy_map


def alloy_reader(alloy_file_pwd):
    '''
    input_reader will read alloy file: ALLOY.hea4s
    This function will open the file and generate alloy composition for each line.
    The input should look like this:
        Cr Mn Fe Co Ni
        Cr Mn Fe Co Ni Al 1.5
        Fe 35 Mn 25 Cr 20 Co 20 
    Unspecified atomic fraction of any element will be taken as 1.
    The composition of the alloys will be normalized to 1.
    The space between any two element/atomic fraction is necessary, else the element/atomic fraction can't be recognized. 
    
    Parameters:
        alloy_file_pwd: path of the ALLOY.hea4s
    
    Returns:
        alloy_map: map of all read alloys. list, each element is an alloy object
    '''

    try:
        alloy_file_content = open(alloy_file_pwd)
        print('ALLOY.hea4s file found!')
    except:
        print('Can not read ALLOY.hea4s! Please check the input file!')
        dum = input('Press Enter to exit.')
    else:
        line_alloy_counter = 0
        alloy_map = []
        for line_alloy in alloy_file_content.readlines():
            #skip first 3 lines
            if line_alloy_counter > 2:
                line_alloy_raw = line_alloy.split()
                
                try:
                    new_alloy_dic = {}
                    previous_content = 'N/A'
                    for current_content in line_alloy_raw:
                        current_content = current_content.upper()
                        if Isfloat(current_content):
                            new_alloy_dic[previous_content] = float(current_content)
                            previous_content = 'N/A'
                        else:
                            #check if the element is valid
                            if not current_content in periodic_table_uppered:
                                raise ValueError
                                
                            if not (Isfloat(previous_content) or previous_content == 'N/A'):
                                new_alloy_dic[previous_content] = 1
                            previous_content = current_content
                    
                    if not (Isfloat(previous_content) or previous_content == 'N/A'):#if the line_alloy end with an element
                        new_alloy_dic[previous_content] = 1
                    
                    #normalization
                    new_alloy_dic = dic_normalization(new_alloy_dic)
                    
                    #using class alloy
                    new_alloy = alloy(new_alloy_dic)
                    
                except:
                    print('Warning! Cannot understand line'+str(line_alloy_counter + 1)+': '+line_alloy+' in Alloy.hea4s')
                    print('Calculation will skip line'+str(line_alloy_counter + 1)+' in Alloy.hea4s and continue.')
                else:
                    alloy_map.append(new_alloy)
            
            line_alloy_counter = line_alloy_counter + 1
        print('Successfully read alloys!\n')
        return alloy_map
        
def input_reader(input_file_pwd):
    '''
    input_reader will read input file: INPUT_PARAMETERS.hea4s
    This function will open the file and search every line to see if it matchs any key word
    summary of key words: TEM(and the number following it):temperature  SPIN:spinodal
    
    Parameters:
        input_file_pwd: path of the INPUT_PARAMETERS.hea4s
    
    Returns:
        INPUT_PARAMETERS: an input_demand object
    '''
    try:
        input_file_content = open(input_file_pwd)
        print('INPUT_PARAMETERS.hea4s file found!')
    except:
        print('Can not read INPUT_PARAMETERS.hea4s! Please check the input file!')
        dum = input('Press Enter to exit.')
        
    else:
        INPUT_PARAMETERS = input_demand()
        SPINODAL_flag = False
        TEMPERATURE_flag = False
        line_input_counter = 0
        
        for line_input in input_file_content.readlines():
            #skip first 3 lines!!
            if line_input_counter > 2:
                line_input = line_input.upper()
                
                #Temperature
                if re.search(r'TEM',line_input):
                    pattern_tem = re.compile(r'\d+\.*\d*')
                    INPUT_PARAMETERS.Temperature = float(re.findall(pattern_tem,line_input)[0])
                    if TEMPERATURE_flag:
                        print('Warning! More than one temperature found!')
                        print('Calculation will continue with new temperature: '+str(INPUT_PARAMETERS.Temperature)+' K.')
                    else:
                        print('Temperature found: '+ str(INPUT_PARAMETERS.Temperature)+' K.\n')
                    TEMPERATURE_flag = True
                
                #Spinodal
                if re.search(r'SPIN',line_input):
                    if re.search(r'FALSE', line_input):
                        INPUT_PARAMETERS.Do_SPINODAL = False
                        if SPINODAL_flag:
                            print('Warning! More than one spinodal decomposition mode found!')
                            print('Calculation will continue with new spinodal decomposition mode: '+ str(INPUT_PARAMETERS.Do_SPINODAL))
                        else:
                            print('Spinodal decomposition mode found: '+ str(INPUT_PARAMETERS.Do_SPINODAL))
                    if re.search(r'TRUE', line_input):
                        INPUT_PARAMETERS.Do_SPINODAL = True
                        if SPINODAL_flag:
                            print('Warning! More than one spinodal decomposition mode found!')
                            print('Calculation will continue with new spinodal decomposition mode: '+ str(INPUT_PARAMETERS.Do_SPINODAL))
                        else:
                            print('Spinodal decomposition mode found: '+ str(INPUT_PARAMETERS.Do_SPINODAL))        
                        SPINODAL_flag = True 
               
            line_input_counter = line_input_counter + 1
        
        input_file_content.close()
        print('Successfully read input parameters:\n'+str(INPUT_PARAMETERS))
        return INPUT_PARAMETERS
    

def main():
    LOG_FILE=open('LOG_FILE.txt','w')  
    old=sys.stdout 
    sys.stdout=LOG_FILE 
    LOG_FILE.write('start at: ' + str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+'\n')
    
    #read enthalpy
    enthalpy_map = mixing_enthalpy_reader('MIXING_ENTHALPY.hea4s')

    #read alloys you want to calculate
    alloy_map = alloy_reader('ALLOY.hea4s')

    
    
    #read parameters that controls the 
    input_parameter = input_reader('INPUT_PARAMETERS.hea4s')

    
    
    result_file = open('RESULT.txt','w')
    result_file.write('composition # mixing_enthalpy_J/mol #  mixing_entropy_ss_J/molK  # Temperature_K # Is_spinodal # eigenvalue_1 # max_direction_1 # eigenvalue_2 # max_direction_2 #\n')

    

    flush_count = 0
    for alloy in alloy_map:
        
        flush_count = flush_count + 1
        
        if input_parameter.Do_SPINODAL:
            #calculate the spinodal decomposition
            for temperature in range(300,2000):
                alloy.SPINODAL(enthalpy_map,temperature)

                result_file.write(alloy.print_head(enthalpy_map))
                result_file.write(' # ' + str(temperature)+' # ')
                result_file.write(alloy.print_SPINODAL())            
                result_file.write(' # \n')
                              
          
        alloy.clear()
        
        if flush_count%100 == 0:
            result_file.flush()

    
    
    print('Completed!')
    LOG_FILE.write('end at: ' + str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
    result_file.close()
    sys.stdout=old  
    LOG_FILE.close()
    
if __name__ == '__main__':
    #test()
    main()
    
